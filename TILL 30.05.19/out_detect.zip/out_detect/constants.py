epsilon = 0.05
powerToMembershipInFcm = 2
labelValueSeparator = ': '
theta = 0.1
